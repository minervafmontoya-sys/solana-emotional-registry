use anchor_lang::prelude::*;

// El ID se actualizará automáticamente al compilar (Build)
declare_id!("DWwbdy9MC3Mg6Bagc7S1urbThv6qkBr6yNHGVWfqDzij");

#[program]
pub mod emotional_registry {
    use super::*;

    // CREATE: Crear registro emocional con PDA
    pub fn create_emotion(ctx: Context<CreateEmotion>, emotion: String, description: String) -> Result<()> {
        let emotion_account = &mut ctx.accounts.emotion_account;
        emotion_account.author = *ctx.accounts.user.key;
        emotion_account.emotion = emotion;
        emotion_account.description = description;
        emotion_account.timestamp = Clock::get()?.unix_timestamp;
        msg!("Registro emocional creado con éxito.");
        Ok(())
    }

    // UPDATE: Actualizar la emoción existente
    pub fn update_emotion(ctx: Context<UpdateEmotion>, new_emotion: String, new_description: String) -> Result<()> {
        let emotion_account = &mut ctx.accounts.emotion_account;
        emotion_account.emotion = new_emotion;
        emotion_account.description = new_description;
        emotion_account.timestamp = Clock::get()?.unix_timestamp;
        msg!("Registro emocional actualizado.");
        Ok(())
    }

    // DELETE: Borrar cuenta y recuperar renta
    pub fn delete_emotion(_ctx: Context<DeleteEmotion>) -> Result<()> {
        msg!("Registro eliminado. Renta recuperada.");
        Ok(())
    }
}

#[derive(Accounts)]
pub struct CreateEmotion<'info> {
    #[account(
        init, 
        payer = user, 
        space = 8 + 32 + 4 + 50 + 4 + 200 + 8, 
        seeds = [b"emotion", user.key().as_ref()], 
        bump
    )]
    pub emotion_account: Account<'info, EmotionEntry>,
    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct UpdateEmotion<'info> {
    #[account(mut, seeds = [b"emotion", user.key().as_ref()], bump, has_one = author)]
    pub emotion_account: Account<'info, EmotionEntry>,
    pub author: Signer<'info>,
    pub user: Signer<'info>,
}

#[derive(Accounts)]
pub struct DeleteEmotion<'info> {
    #[account(mut, seeds = [b"emotion", user.key().as_ref()], bump, close = user)]
    pub emotion_account: Account<'info, EmotionEntry>,
    #[account(mut)]
    pub user: Signer<'info>,
}

#[account]
pub struct EmotionEntry {
    pub author: Pubkey,
    pub emotion: String,
    pub description: String,
    pub timestamp: i64,
}